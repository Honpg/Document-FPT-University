from typing import List, Tuple
class Graph:
    def __init__(self):
        self.a = []
        self.label = []
        self.n = 0

    def setAMatrix(self, b, m):
        self.n = m
        self.a = b

    def setLabel(self, c):
        self.label = c

    def breadthFirstTraverse(self, v):
        visited = [False] * self.n
        queue = []
        queue.append(v)
        visited[v] = True
        while queue:
            v = queue.pop(0)
            print(self.label[v], end=" ")
            for i in range(self.n):
                if (self.a[v][i] == 1 and (not visited[i])):
                    queue.append(i)
                    visited[i] = True

    def depthFirstTraverse(self, v):
        visited = [False] * self.n
        self.depthFirstTraverseHelper(v, visited)

    def depthFirstTraverseHelper(self, v, visited):
        visited[v] = True
        print(self.label[v], end=" ")
        for i in range(self.n):
            if (self.a[v][i] == 1 and (not visited[i])):
                self.depthFirstTraverseHelper(i, visited)
class WGraph:
    def __init__(self, vertices: int):
        self.V = vertices
        self.graph = [[0] * vertices for _ in range(vertices)]

    def min_distance(self, dist: List[int], spt_set: List[bool]) -> int:
        min_dist = float("inf")
        min_index = -1

        for v in range(self.V):
            if dist[v] < min_dist and not spt_set[v]:
                min_dist = dist[v]
                min_index = v

        return min_index

    def dijkstra(self, src: int) -> List[int]:
        dist = [float("inf")] * self.V
        dist[src] = 0
        spt_set = [False] * self.V

        for _ in range(self.V):
            u = self.min_distance(dist, spt_set)
            spt_set[u] = True

            for v in range(self.V):
                if (
                    self.graph[u][v] > 0
                    and not spt_set[v]
                    and dist[u] != float("inf")
                    and dist[u] + self.graph[u][v] < dist[v]
                ):
                    dist[v] = dist[u] + self.graph[u][v]

        return dist
    def min_key(self, key: List[int], mst_set: List[bool]) -> int:
        min_val = float("inf")
        min_index = -1

        for v in range(self.V):
            if key[v] < min_val and not mst_set[v]:
                min_val = key[v]
                min_index = v

        return min_index
    def prim_mst(self) -> List[Tuple[int]]:
        parent = [-1] * self.V
        key = [float("inf")] * self.V
        key[0] = 0
        mst_set = [False] * self.V

        parent[0] = -1

        for _ in range(self.V):
            u = self.min_key(key, mst_set)
            mst_set[u] = True

            for v in range(self.V):
                if (
                    self.graph[u][v] > 0
                    and not mst_set[v]
                    and key[v] > self.graph[u][v]
                ):
                    key[v] = self.graph[u][v]
                    parent[v] = u

        return [(parent[i], i) for i in range(1, self.V)]
    
def get_content(): 
   with open('Graph.txt', 'r') as f:
    data = f.readlines()

    cleaned_matrix = [] 
    for raw_line in data:
        split_line = raw_line.strip().split(",")
        nums_ls = [int(x.replace('"', '')) for x in split_line] 
        cleaned_matrix.append(nums_ls)
    return cleaned_matrix
g = Graph()
g.setAMatrix(get_content(), 7)
g.setLabel(['A', 'B','C','D','E','F','G'])
print("Breadth-First Traversal:")
g.breadthFirstTraverse(0)
print("\nDepth-First Traversal:")
g.depthFirstTraverse(0)

    
