from Car import *
from Node import *
class NodeQ:
    def __init__(self,data):
        self.data = data
        self.next = None
class MyQueue:
    def __init__(self):
        self.head = None
        self.tail = None
    def isEmpty(self):
        return self.head ==None
    def EnQueue(self, data):
        node = NodeQ(data)
        if self.isEmpty():
            self.head = node
            self.tail = node
        else:
            self.tail.next = node
            self.tail = node
    #end def
    def DeQueue(self):
        if self.isEmpty():
            return None
        data = self.head.data
        self.head = self.head.next
        return data
#end class    
class BSTree:
    def __init__(self):
        self.root = None
    # end def
    def clear(self):
        self.root = None
    def isEmpty(self):
        return self.root == None
    #end def
    def insert(self,name, price):
        # ===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART========
       
        
        #########################
        pass
    #end def
    def visit(self,p,file):
        if p is not None:
            file.write(str(p.data) + " ")

    #end def
    def preOrder(self,p,file):
        if p==None:
            return
        self.visit(p,file)
        self.preOrder(p.left,file)
        self.preOrder(p.right,file)
    #end def
    def preVisit(self, file):
        self.preOrder(self.root, file)
    #end def
    def postOrder(self,p,file):
        if p==None:
            return
        self.postOrder(p.left,file)
        self.postOrder(p.right,file)
        self.visit(p,file)
    #end def
    def postVisit(self,file):
        self.postOrder(self.root,file)
    #end def
    def inOrder(self,p,file):
        if p==None:
            return
        self.inOrder(p.left,file)
        self.visit(p,file)
        self.inOrder(p.right,file)        
    #end def
    def inVisit(self,file):
        self.inOrder(self.root, file)
    #end def
    def breadth_first(self,file):
        if self.isEmpty():
            return
        my = MyQueue()
        my.EnQueue(self.root)
        while not my.isEmpty():
            p = my.DeQueue()
            self.visit(p,file)
            if p.left!=None:
                my.EnQueue(p.left)
            if p.right!=None:
                my.EnQueue(p.right)
        print("")        
    #end def
    def f2(self,file):
        # ===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART========
    



        ####################
        pass
    def f3(self,file):
        # ===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART========
        
        
        #############################    
        pass
    def f4(self,file):
        #  ===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART========


        #################################
        pass


# end class
