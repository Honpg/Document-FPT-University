from BSTree import *
from Car import *
import re
class Main:
    def __init__(self,fileName):
        self.fileName = fileName
        self.data = None
    #end def    
    def readFile(self, lineStart, numberline):
        f1 = open(self.fileName,'r');
        count =0
        while True:        
            count+=1
            line = f1.readline()
            if not line:
                break
            if count== lineStart+1:                
                listName = re.sub("\s+"," ",line.strip()).split(" ")                
                self.data =[listName];
            if count>lineStart+1 and count<lineStart+1+numberline: 
                # line = f1.readline()
                listValue = re.sub("\s+"," ",line.strip()).split(" ")
                b =[]
                for i in range(len(listValue)):
                    b.append(int(listValue[i]))
                self.data.append(b)
        f1.close()
    def display(self):
        for line in self.data:
            print(line, end ="\n")        
                # listName = line.strip().split(", ")
    def f1(self, tree):
        for i in range(len(self.data[0])):           
            tree.insert(self.data[0][i],self.data[1][i])
    #end def       
    def createTree(self,tree,begin=0, end=0):
        self.readFile(begin, end)
        for i in range(len(self.data[0])):
            tree.insert(self.data[0][i],self.data[1][i])
#####################            
m = Main("input.txt")
tree = BSTree()
   
m.readFile(1,2)
m.f1(tree)
with open("f1.txt", "w") as f:
    tree.preVisit(f)
    f.write("\n") 
    tree.inVisit(f)    

tree.clear()
m.createTree(tree,4,2)  
with open("f2.txt", "w") as f:
    tree.preVisit(f)
    f.write("\n") 
    tree.f2(f)

tree.clear()
m.createTree(tree,7,2)
with open("f3.txt", "w") as f:
    tree.breadth_first(f)
    f.write("\n") 
    tree.f3(f)     
    tree.breadth_first(f)

tree.clear()
m.createTree(tree,10,2)
with open("f4.txt", "w") as f:
    tree.breadth_first(f)
    f.write("\n") 
    tree.f4(f)
    tree.breadth_first(f)    