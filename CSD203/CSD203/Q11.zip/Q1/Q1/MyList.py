from Car import *
from Node import *
class MyList:
    def __init__(self):
        self.head = None
        self.tail = None
    def isEmpty(self):
        return self.head ==None
    def traverse(self, file):   
        pt=self.head
        while pt:
            file.write(str(pt.data) + " ")
            pt = pt.next        
    def clear(self):
        self.head = None
#Q1-1
    def addLast(self, name="", price=-1):
        # ===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART========
        if name[0] == 'B' or price > 100:
            return
        else:
            car = Car(name, price)
            node = Node(car)
            if self.head == None:
                self.head = node
            else:
                current = self.head
                while current.next:
                    current = current.next
                current.next = node
            
    # end def
#Q1-2    
    def addFirst(self, name="", price=-1):
        # ===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART========
        car = Car(name, price)
        node = Node(car)
        if self.head == None:
            self.head = node
        else:
            node.next = self.head
            self.head = node

    # end def
#Q1-3
    def delete(self, price =0):
        # ===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART========
        current = self.head
        previous = None
        while current.next:
            if current.data.Price == 5:
                previous.next = current.next
                break
            previous = current
            current = current.next
    #end def
# Q1-4
    def sort(self):
        # ===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART========
        list_ = []
        current = self.head
        while current.next:
            list_.append([int(current.data.Price), current.data.Name])
            current = current.next
        list_.append([int(current.data.Price), current.data.Name])
        list_ = sorted(list_, reverse=False)
        self.head = None
        while len(list_) != 0:
            self.addLast(list_[0][1], list_[0][0])
            list_ = list_[1:]
        
        
        
                         
    #end def
# Q1-5
    def reverse(self):
        # ===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART========
        list_ = []
        current = self.head
        while current.next:
            list_.append([current.data.Price, current.data.Name])
            current = current.next
            
        list_.append([current.data.Price, current.data.Name])
        self.head = None
        while len(list_) != 0:
            self.addFirst(list_[0][1], list_[0][0])
            list_ = list_[1:]
            
            
            
            
        
        
    #end def