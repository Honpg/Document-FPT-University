from MyList import *
from Car import *
import re
class Main:
    def __init__(self,fileName):
        self.fileName = fileName
        self.data = None
    #end def    
    def readFile(self, lineStart, numberline):
        f1 = open(self.fileName,'r')
        count =0
        while True:        
            count+=1
            line = f1.readline()
            if not line:
                break
            if count== lineStart+1:
                LineName = re.sub('\s+',' ',line.strip())
                listName = LineName.split(" ")
                self.data =[listName]
            if count>lineStart+1 and count<lineStart+1+numberline:                 
                b = []
                LineValue = re.sub('\s+',' ',line.strip())
                listValue = LineValue.split(" ")
                for i in range(len(listValue)):
                    b.append(int (listValue[i]))
                self.data.append(b)
        f1.close()
    def display(self):
        for line in self.data:
            print(line, end ="\n")        
                # listName = line.strip().split(", ")
    def f1(self, linkList):
        for i in range(len(self.data[0])):
            linkList.addLast(self.data[0][i],self.data[1][i])
    #end def       
    def creatList(self,linkList,begin=0, end=0):
        self.readFile(begin, end)
        for i in range(len(self.data[0])):
            linkList.addLast(self.data[0][i],self.data[1][i])
#####################            
m = Main('input.txt')
linkList = MyList()

with open("f1.txt", "w") as file:
    m.readFile(1,2)
    m.f1(linkList)
    linkList.traverse(file)

with open("f2.txt", "w") as file:
    linkList.clear()
    m.creatList(linkList,4,2)
    linkList.traverse(file)
    linkList.addFirst("X", 1)
    file.write("\n")
    linkList.traverse(file)

with open("f3.txt", "w") as file:
    linkList.clear()
    m.creatList(linkList,7,2)   
    linkList.traverse(file) 
    linkList.delete(5)
    file.write("\n")
    linkList.traverse(file)

with open("f4.txt", "w") as file:
    linkList.clear()
    m.creatList(linkList,10,2)
    linkList.traverse(file)
    linkList.sort()
    file.write("\n")
    linkList.traverse(file)

with open("f5.txt", "w") as file:
    linkList.clear()
    m.creatList(linkList,13,2)
    linkList.traverse(file)
    linkList.reverse()
    file.write("\n")
    linkList.traverse(file)